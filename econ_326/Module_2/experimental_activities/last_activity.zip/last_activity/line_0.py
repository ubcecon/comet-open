# Import module
from tkinter import *
from turtle import color
import time
from datetime import datetime
import pandas as pd
import csv
import numpy
# Create object
start_end=[]
root = Tk()

file = open('Names.csv')
csvreader = csv.reader(file)
mat=pd.DataFrame(csvreader)
mat.drop(0,)
mat.rename(columns = {0:'w', 1:'i'}, inplace = True)

# Adjust size
root.geometry("400x400")

# Add image file
bg = PhotoImage(file = "plot.png")

# Create Canvas
canvas1 = Canvas( root, width = 400,
				height = 500)

canvas1.pack(fill = "both", expand = True)

# Display image
canvas1.create_image( 0, 0, image = bg,
					anchor = "nw")

# Add Text
#canvas1.create_text( 200, 250, text = "Welcome")

# Create Buttons
'''
button1 = Button( root, text = "Exit")
button3 = Button( root, text = "Start")
button2 = Button( root, text = "Reset")
'''
# Display Buttons

def f(x):
    if  x.isdigit():
        return True

def get_r2(b1,b0):
    global mat
    actual=filter(f,mat['w']) 
    actual = list(map(float,actual))
    p = lambda x : b0 +b1*x
    predict=filter(f,mat['i'])
    predict=list(map(float,predict))
    predict = list(map(p,predict))
    corr_matrix = numpy.corrcoef(actual[0:len(predict)], predict)
    corr = corr_matrix[0,1]
    R_sq = corr**2
    return R_sq

def get_specs(c):
    sfy= (3* (10**7))/500
    sfx=(3*(10*6)/400)
    sf= 8
    canvas1.create_image( 0, 0, image = bg,anchor = "nw")
    ps=[start_end[0],start_end[len(start_end) -1]]
    canvas1.create_line(ps[0][0], ps[0][1], ps[1][0],ps[1][1], width=2)
    b1=(ps[1][1]-ps[0][1] ) /(ps[0][0] -ps[0][1])*sf 
    b0= (ps[0][1])*sfy - (b1*sfx *ps[0][0])
    R_2=get_r2(b1,b0)
    list=['intercept:',b0]
    list1=['slope:', b1]
    list2=['R^2',R_2]
    text = Label(canvas1, text=str(list))
    text.place(x=300,y=250)
    text1 = Label(canvas1, text=str(list1))
    text1.place(x=300,y=300)
    text2 = Label(canvas1, text=str(list2))
    text2.place(x=300,y=350)

def click(click_event):
    global start_end
    global prev
    canvas1.create_image( 0, 0, image = bg,anchor = "nw")
    prev = click_event
    canvas1.create_image( 0, 0, image = bg,anchor = "nw")
    cords=[prev.x,prev.y]
    start_end.append(cords)
    if (len(start_end) > 2):
        get_specs(start_end)
b=0

def move(move_event):
    global b
    global prev
    a=time.perf_counter()
    if(a-b> .1):
        canvas1.create_line(prev.x, prev.y, move_event.x, move_event.y, width=2)
        b=time.perf_counter()
        prev = move_event  # what does this do ?








canvas1.bind('<Button-1>', click)

canvas1.bind('<B1-Motion>', move)

#cords2=canvas1.bind('<Button-2>', click)
#stat_line(cords1,cords2)


'''
button1_canvas = canvas1.create_window( 100, 10,
									anchor = "nw",
									window = button1)

button2_canvas = canvas1.create_window( 100, 40,
									anchor = "nw",
									window = button2)

button3_canvas = canvas1.create_window( 100, 70, anchor = "nw",
									window = button3)

'''

# Execute tkinter
root.mainloop()
